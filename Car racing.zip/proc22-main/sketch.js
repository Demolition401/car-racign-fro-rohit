function setup(){
  var canvas=createCanvas(400,400);
}
function draw()
{
  background(0);
  rectMode(CENTER);
    rect(200,200,50,50);
  
}
